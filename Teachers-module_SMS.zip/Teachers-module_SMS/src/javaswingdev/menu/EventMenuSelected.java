package javaswingdev.menu;

public interface EventMenuSelected {

    public void menuSelected(int index, int indexSubMenu);
}
