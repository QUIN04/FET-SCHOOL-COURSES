package javaswingdev.main;

import java.awt.Color;
import java.awt.Component;
import javaswingdev.form.Form_About;
import javaswingdev.form.Form_Dashboard;
import javaswingdev.form.Form_Empty;
import javaswingdev.form.Form_Group;
import javaswingdev.form.Form_Profile;
import javaswingdev.form.Form_Progress;
import javaswingdev.form.Form_Project;
import javaswingdev.form.Form_RT;
import javaswingdev.form.Form_RTT;
import javaswingdev.form.Form_Requirements;
import javaswingdev.form.Form_TAF;
import javaswingdev.form.Form_Time;
import javaswingdev.form.Form_Timetable_l;
import javaswingdev.form.Form_chat_app;
import javaswingdev.form.Form_email;
import javaswingdev.form.Form_email_c;
import javaswingdev.form.Form_email_r;
import javaswingdev.form.Form_help;
import javaswingdev.form.Form_info;
import javaswingdev.form.Form_lib;
import javaswingdev.form.Form_results;
import javaswingdev.form.Form_settings;
import javaswingdev.form.calendar;
import javaswingdev.menu.EventMenuSelected;

public class Main extends javax.swing.JFrame {

    private static Main main;

    public Main() {
        initComponents();
        init();
        getContentPane().setBackground(Color.white);
    }

    private void init() {
        main = this;
        titleBar.initJFram(this);
        menu.addEvent(new EventMenuSelected() {
            @Override
            public void menuSelected(int index, int indexSubMenu) {
//dashboard
                if (index == 0 && indexSubMenu == 0) {
                    showForm(new Form_Dashboard());
                } //for the email section
                else if (index == 1 && indexSubMenu == 1) {
                    showForm(new Form_email());
                } else if (index == 1 && indexSubMenu == 2) {
                    showForm(new Form_email_r());
                } else if (index == 1 && indexSubMenu == 3) {
                    showForm(new Form_email_c());
                    //  for chat
                } else if (index == 2 && indexSubMenu == 0) {
                    showForm(new Form_chat_app());
                } //for calendar 
                else if (index == 3 && indexSubMenu == 0) {
                    showForm(new calendar());
                } //for taf
                else if (index == 4 && indexSubMenu == 1) {
                    showForm(new Form_TAF());
                } else if (index == 4 && indexSubMenu == 2) {
                    showForm(new Form_Group());
                } else if (index == 4 && indexSubMenu == 3) {
                    showForm(new Form_Project());
                } //for results 
                else if (index == 5 && indexSubMenu == 1) {
                    showForm(new Form_results());
                } else if (index == 5 && indexSubMenu == 2) {
                    showForm(new Form_RT());
                } else if (index == 5 && indexSubMenu == 3) {
                    showForm(new Form_RTT());
                } //for progress cgecking
                else if (index == 6 && indexSubMenu == 8) {
                    showForm(new Form_Progress());//delete email later
                } //for req
                else if (index == 7 && indexSubMenu == 1) {
                    showForm(new Form_Requirements());//for fees
                } else if (index == 7 && indexSubMenu == 2) {
                    showForm(new Form_info());//info
                } else if (index == 7 && indexSubMenu == 3) {
                    showForm(new Form_lib());//lib

                } //for timetable
                else if (index == 8 && indexSubMenu == 1) {
                    showForm(new Form_Time());
                } else if (index == 8 && indexSubMenu == 2) {
                    showForm(new Form_Timetable_l());//lab
                } //for profiling
                else if (index == 9 && indexSubMenu == 1) {
                    showForm(new Form_Profile());//info
                } else if (index == 9 && indexSubMenu == 2) {
                    showForm(new Form_settings());//info
                } //for about
                else if (index == 10 && indexSubMenu == 1) {
                    showForm(new Form_About());//FAQ
                } else if (index == 10 && indexSubMenu == 2) {
                    showForm(new Form_help());//help
                } //logout       
                else if (index == 11 && indexSubMenu == 0) {

                } else {
                    showForm(new Form_Empty(index + " " + indexSubMenu));
                }
            }
        }
        );
        menu.setSelectedIndex(0, 0);
    }

    public void showForm(Component com) {
        body.removeAll();
        body.add(com);
        body.repaint();
        body.revalidate();
    }

    public static Main getMain() {
        return main;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        background = new javax.swing.JPanel();
        panelMenu = new javax.swing.JPanel();
        titleBar = new javaswingdev.swing.titlebar.TitleBar();
        menu = new javaswingdev.menu.Menu();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        body = new javax.swing.JPanel();
        header1 = new com.raven.component.Header();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        background.setBackground(new java.awt.Color(245, 245, 245));

        panelMenu.setBackground(new java.awt.Color(255, 255, 255));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(menu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(titleBar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                .addComponent(titleBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, 566, Short.MAX_VALUE))
            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jSeparator1)
        );

        body.setBackground(new java.awt.Color(204, 204, 255));
        body.setOpaque(false);
        body.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addComponent(panelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(header1, javax.swing.GroupLayout.DEFAULT_SIZE, 902, Short.MAX_VALUE)
                    .addComponent(body, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addComponent(header1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(body, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel background;
    private javax.swing.JPanel body;
    private com.raven.component.Header header1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javaswingdev.menu.Menu menu;
    private javax.swing.JPanel panelMenu;
    private javaswingdev.swing.titlebar.TitleBar titleBar;
    // End of variables declaration//GEN-END:variables

    private static class getContentPane {

        private static void setBackground(Color white) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public getContentPane() {
        }
    }
}
