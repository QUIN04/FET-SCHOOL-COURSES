package javaswingdev.menu;

public interface EventMenuSelected {

    public void menuSelected(int menuIndex, int subMenuIndex);
}
